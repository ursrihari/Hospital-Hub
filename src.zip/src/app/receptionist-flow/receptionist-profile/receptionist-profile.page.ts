import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-receptionist-profile',
  templateUrl: './receptionist-profile.page.html',
  styleUrls: ['./receptionist-profile.page.scss'],
})
export class ReceptionistProfilePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
