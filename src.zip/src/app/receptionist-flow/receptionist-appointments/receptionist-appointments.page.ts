import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-receptionist-appointments',
  templateUrl: './receptionist-appointments.page.html',
  styleUrls: ['./receptionist-appointments.page.scss'],
})
export class ReceptionistAppointmentsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
