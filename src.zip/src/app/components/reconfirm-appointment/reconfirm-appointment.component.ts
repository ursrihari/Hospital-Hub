import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reconfirm-appointment',
  templateUrl: './reconfirm-appointment.component.html',
  styleUrls: ['./reconfirm-appointment.component.scss'],
})
export class ReconfirmAppointmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
