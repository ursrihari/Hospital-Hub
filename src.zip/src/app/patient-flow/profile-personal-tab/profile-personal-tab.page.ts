import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-personal-tab',
  templateUrl: './profile-personal-tab.page.html',
  styleUrls: ['./profile-personal-tab.page.scss'],
})
export class ProfilePersonalTabPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
