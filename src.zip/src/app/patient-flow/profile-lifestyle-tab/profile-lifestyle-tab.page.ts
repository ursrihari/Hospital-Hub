import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-lifestyle-tab',
  templateUrl: './profile-lifestyle-tab.page.html',
  styleUrls: ['./profile-lifestyle-tab.page.scss'],
})
export class ProfileLifestyleTabPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
