import { Injectable } from '@angular/core';
import { Sim } from '@ionic-native/sim/ngx';

@Injectable({
  providedIn: 'root'
})
export class PluginService {

  constructor(private sim:Sim) { }
  /*SIM Plugin */
  async getSimInfo(){
    await this.sim.getSimInfo().then( (info) => { return info },
    (err) => console.log('Unable to get sim info: ', err)
  );
    this.sim.hasReadPermission().then(
      (info) => console.log('Has permission: ', info)
    );

    this.sim.requestReadPermission().then(
      () => console.log('Permission granted'),
      () => console.log('Permission denied')
    );
  }
  /*SIM Plugin */

}
