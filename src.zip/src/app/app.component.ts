import { Component } from '@angular/core';
import { MenuController, NavController, Platform } from '@ionic/angular';
import { AuthService,AccountService } from '@app/services';
//import { StatusBar } from '@ionic-native/status-bar/ngx';
//import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { User } from '@app/model';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  activePageTitle = 'appointment-details';
  UserPages=[];
  MenuPages=[];
  user: User;
  user_role;
  constructor(private authService: AuthService,
    private menuCtrl:MenuController,
    private navCtrl: NavController,
    private accountService: AccountService,
     private platform: Platform
    //private statusBar: StatusBar,
     //private splashScreen: SplashScreen
    ){

      this.accountService.user.subscribe(x => this.user = x);

      this.authService.getUser().subscribe(user=> {
        console.log(user);
        //user = {name: "", mobile: 2222222222, role: 1};

        if(user){
          if(user.role == 0){
            this.initializeApp('patient');
            this.user_role = 0;
          }else if(user.role == 1){
            this.initializeApp('doctor');
            this.user_role = 1;
          }else if(user.role == 2){
            this.initializeApp('receptionist');
            this.user_role = 2;
          }
          this.menuCtrl.enable(true);
        }
      });
  }
  
  initializeApp(role){
   // this.platform.ready().then(() => {
      //this.statusBar.overlaysWebView(true);
      //this.statusBar.backgroundColorByHexString('#ffffff');
      //this.statusBar.styleDefault();
      // //this.splashScreen.hide();
      // //this.splashScreen.show();
      // this.splashScreen.show({
      //   showDuration: 2000,
      //   autoHide: true
      // });
    //});
    //role= 'doctor';
    switch(role) { 
      case 'patient': { 
        this.UserPages = [
          {title: 'Home', page: 'PatientHomePage', url:'patient-home', icon:'fa fa-home'},
          {title: 'Appointments', page: 'PatientAppointmentsPage', url:'patient-appointments', icon:'fa fa-calendar'},
          {title: 'Test Bookings', page: 'TestBookingsPage', url:'test-bookings', icon:'fa fa-flask'},
          {title: 'Consultations', page: 'ConsultationsPage', url:'consultations', icon:'fa fa-calendar'},
          {title: 'My Doctors', page: 'MyDoctorsPage', url:'my-doctors', icon:'fa fa-user-md'},
          {title: 'Medical Records', page: 'MedicalRecordsPage', url:'medical-records', icon:'fa fa-home'},
          {title: 'Reminders', page: 'RemindersPage', url:'reminders', icon:'fa fa-clock-o'}
        ];
        this.MenuPages = [
            {title: 'Read about health', page: 'ReadAboutHealthPage', url:'read-about-health', icon:'fa fa-heartbeat'},
            {title: 'Hep Center', page: 'HelpCenterPage', url:'help-center', icon:'fa fa-question-circle'},
            {title: 'Settings', page: 'SettingsPage', url:'settings', icon:'fa fa-cog'},
            {title: 'Like us? Give us 5 stars', page: 'like-us-give-5-star', url:'like-us-give-5-star', icon:'fa fa-thumbs-o-up'}
        ];
         break; 
      } 
      case 'doctor': { 
        this.UserPages = [
          {title: 'Appointments', page: 'DoctorAppointmentsPage', url:'doctor-appointments', icon:'home'},
          {title: 'Profile', page: 'DoctorProfilePage', url:'doctor-profile', icon:'home'}
        ];
         break; 
      } 
      case 'receptionist': { 
        this.UserPages = [
          {title: 'Appointments', page: 'ReceptionistAppointmentsPage', url:'receptionist-appointments', icon:'home'},
          {title: 'Profile', page: 'ReceptionistProfilePage', url:'receptionist-profile', icon:'home'}
        ];
         break; 
      } 
   }
  }
  openMenuPage(pageurl){
    if(pageurl == 'like-us-give-5-star'){
        alert("open playstore to give rating");
    }else{
      this.navCtrl.navigateRoot(pageurl);
    }
      
  }
  openProfile(){
    this.menuCtrl.close();
    this.navCtrl.navigateRoot('patient-profile');
  }
  logout() {
    this.accountService.logout();
}
}
