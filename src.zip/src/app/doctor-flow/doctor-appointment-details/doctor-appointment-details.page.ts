import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doctor-appointment-details',
  templateUrl: './doctor-appointment-details.page.html',
  styleUrls: ['./doctor-appointment-details.page.scss'],
})
export class DoctorAppointmentDetailsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
