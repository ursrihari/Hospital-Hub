import { Component, OnInit } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { NavController, IonMenu,MenuController } from '@ionic/angular';
import { Router,ActivatedRoute } from '@angular/router';
import { User } from '../model/User';
import { first } from 'rxjs/operators';
import { SmsRetriever } from '@ionic-native/sms-retriever/ngx';

@Component({
  selector: 'app-otp-verification',
  templateUrl: './otp-verification.page.html',
  styleUrls: ['./otp-verification.page.scss'],
})
export class OtpVerificationPage implements OnInit {
    mobile:number;
    otp:number = 12345;
    OTPmessage: string = 'An OTP is sent to your number. You should receive it in 15 s'
  constructor(private navCtrl: NavController, 
    private authService: AuthService,
    private router:Router,
    private route:ActivatedRoute,
    private menuCtrl:MenuController,
    private smsRetriever: SmsRetriever) { 

      this.smsRetriever.getAppHash()
      .then((res: any) => console.log(res))
      .catch((error: any) => console.error(error));
    }

  ngOnInit() {
    this.mobile = parseInt(this.route.snapshot.paramMap.get('mobile'),10);
    console.log(this.mobile);
  }
  start() {
    this.smsRetriever.startWatching()
      .then((res: any) => {
        console.log(res);
        this.processSMS(res);
      })
      .catch((error: any) => console.error(error));
  }
  processSMS(data) {
    // Design your SMS with App hash so the retriever API can read the SMS without READ_SMS permission
    // Attach the App hash to SMS from your server, Last 11 characters should be the App Hash
    // After that, format the SMS so you can recognize the OTP correctly
    // Here I put the first 6 character as OTP
    const message = data.Message;
    if (message != -1) {
      this.otp = message.slice(0, 6);
      console.log(this.otp);
      this.OTPmessage = 'OTP received. Proceed to register';
      //this.presentToast('SMS received with correct app hash', 'bottom', 1500);
    }
  }
  verifyOtp(){
    this.authService.setUser();
    console.log(this.route.snapshot.paramMap.get('mobile'));
    //this.router.navigateByUrl('/patient-home');
    this.navCtrl.navigateRoot('patient-home');
    // this.authService.verifyOtp(this.mobile,this.otp)
    //         .pipe(first())
    //         .subscribe({
    //             next: (user) => {
    //               console.log(user);
    //                 if(user){
    //                   if(user.role == 0){
    //                     this.router.navigateByUrl('/patient-home');
    //                 }else if(user.role == 1){
    //                   this.router.navigateByUrl('/doctor-appointments');
    //                 }else if(user.role == 2){
    //                   this.router.navigateByUrl('/receptionist-appointments');
    //                 }
    //               }
    //             },
    //             error: error => {
    //                // this.alertService.error(error);
    //                 //this.loading = false;
    //             }
    //         });

    //   this.authService.verifyOtp(this.mobile,this.otp).subscribe(user=> {
    //     console.log(user);
    //   if(user){
    //     if(user.role == 0){
    //       this.router.navigateByUrl('/patient-home');
    //   }else if(user.role == 1){
    //     this.router.navigateByUrl('/doctor-appointments');
    //   }else if(user.role == 2){
    //     this.router.navigateByUrl('/receptionist-appointments');
    //   }
    // }
    // });
  }
  backToLoginPage(){
    this.navCtrl.pop();
  }
  openHelpPage(){
    this.router.navigateByUrl('/help');
  }
}
