import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-medical-tab',
  templateUrl: './profile-medical-tab.page.html',
  styleUrls: ['./profile-medical-tab.page.scss'],
})
export class ProfileMedicalTabPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
