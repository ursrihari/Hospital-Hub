import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-enter-delivery-pincode',
  templateUrl: './enter-delivery-pincode.page.html',
  styleUrls: ['./enter-delivery-pincode.page.scss'],
})
export class EnterDeliveryPincodePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
