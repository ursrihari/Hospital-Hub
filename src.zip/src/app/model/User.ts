export interface User{
    name:string;
    mobile:number;
    role: number;
    id: string;
    username: string;
    password: string;
    firstName: string;
    lastName: string;
    token: string;
}