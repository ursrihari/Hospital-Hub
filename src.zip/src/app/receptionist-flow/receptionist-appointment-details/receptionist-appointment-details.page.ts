import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-receptionist-appointment-details',
  templateUrl: './receptionist-appointment-details.page.html',
  styleUrls: ['./receptionist-appointment-details.page.scss'],
})
export class ReceptionistAppointmentDetailsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
